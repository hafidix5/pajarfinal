<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
              <a  href="<?php echo e(route('ramodifAdminExport',[$idAnak,$idJenisEdukasi])); ?>" class="btn btn-success my-3" target="_blank">EXPORT EXCEL</a>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                      <th>
                        Tanggal
                      </th>
                      <th>
                        Nama Anak
                      </th>
                      <th>
                        Tahap
                      </th>
                      <th>
                        Pertanyaan
                      </th>
                    <th>
                        Jawaban
                    </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hasilRamodif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasilRamodif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hasilRamodif->waktu); ?></td>
                            <td><?php echo e($hasilRamodif->namaAnak); ?></td>
                            <td><?php echo e($hasilRamodif->tahap); ?></td>
                            <td><?php echo e($hasilRamodif->pertanyaan); ?></td>
                            <td><?php echo e($hasilRamodif->jawaban); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Hasil Kuesioner Ramodif', 'titlePage' => __('Hasil Kuesioner Ramodif')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/hasilRamodifAdmin.blade.php ENDPATH**/ ?>