<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('ramodif.update',$ramodif->id )); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Ubah Rawat Modifikasi')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>

                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nama')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                    <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('Nama')); ?>" value="<?php echo e($ramodif->nama); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Link Video')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('video') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('video') ? ' is-invalid' : ''); ?>" name="video" id="input-video" type="text" placeholder="<?php echo e(__('link video')); ?>" value="<?php echo e($ramodif->video); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('video')): ?>
                          <span id="video-error" class="error text-danger" for="input-video"><?php echo e($errors->first('video')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Jenis Edukasi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('jenisEdukasi_id') ? ' has-danger' : ''); ?>">
                        <select class="form-control" class="form-control" name="jenisEdukasi_id" id="jenisEdukasi_id">

                            <?php $__currentLoopData = $jenisEdukasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisEdukasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
                                <?php if($ramodif->idjenis==$jenisEdukasi->id): ?>
                                <option value="<?php echo e($jenisEdukasi->id); ?>" selected><?php echo e($jenisEdukasi->nama); ?></option>
                                <?php endif; ?>
                          <option value="<?php echo e($jenisEdukasi->id); ?>"><?php echo e($jenisEdukasi->nama); ?></option>
                            }
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        <?php if($errors->has('jenisEdukasi_id')): ?>
                          <span id="jenisEdukasi_id-error" class="error text-danger" for="input-jenisEdukasi_id"><?php echo e($errors->first('jenisEdukasi_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>


              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Ramodif', 'titlePage' => __('Ubah Ramodif')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/ramodifEdit.blade.php ENDPATH**/ ?>