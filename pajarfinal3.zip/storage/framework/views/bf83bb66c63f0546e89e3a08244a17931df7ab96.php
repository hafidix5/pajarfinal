<?php $__env->startSection('content'); ?>
  <div class="content">
    <h3 style="color:blue;"><?php echo e($detekos->nama); ?></h3>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                        <th>
                            Nomor
                        </th>
                      <th>
                        Pertanyaan
                      </th>

                    <th>
                        Aksi
                    </th>

                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $pertanyaan_detekos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan_detekos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pertanyaan_detekos->id); ?></td>
                            <td><?php echo e($pertanyaan_detekos->pertanyaan); ?></td>

                            <td>
                                <a class="nav-link" href="<?php echo e(route('pertanyaan_detekos.edit',$pertanyaan_detekos->id)); ?>">
                                    <i class="material-icons">edit</i> Edit
                                  </a>
                                   <a class="nav-link" href="<?php echo e(route('pertanyaan_detekos.hapus',$pertanyaan_detekos->id)); ?>">
                                    <i class="material-icons">remove_circle</i> Hapus
                                  </a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(url('pertanyaan_detekos.insert',$detekos->id)); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
                </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Daftar Pertanyaan Deteks' , 'titlePage' => __('Daftar Pertanyaan Deteks ')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/pertanyaan_detekosIndex.blade.php ENDPATH**/ ?>