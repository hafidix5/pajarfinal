<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Nama Anak')); ?></h4>
              </div><br>
              <?php $__currentLoopData = $anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="btn btn-outline-secondary btn-lg btn-block" href="<?php echo e(route('kuesioner_ramodif',[$anak->id,$id_jenisEdukasi])); ?>"><?php echo e($anak->nama); ?></a>
              <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
      </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Pilih Anak', 'titlePage' => __('Pilih Anak')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/pilihAnakRamodif.blade.php ENDPATH**/ ?>