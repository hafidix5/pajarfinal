<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Data Anak</h4>
      </div>

      <div class="card-body">
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e(session('status')); ?></span>
            </div>
          </div>
        </div>
      <?php endif; ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="">
              <th>
                Nama
              </th>
              <th>
                Tanggal Lahir
              </th>
              <th>
                Usia
              </th>
              <th>
                Jenis Kelamin
              </th>
              <th>
                Anak Ke-
              </th>
            <th>
                Aksi
            </th>

            </thead>
            <tbody>
                <?php $__currentLoopData = $anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($anak->nama); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($anak->tgl_lahir)->format('d/m/Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($anak->tgl_lahir)->age); ?></td>
                    <td><?php echo e($anak->jenis_kelamin); ?></td>
                    <td><?php echo e($anak->anak_ke); ?></td>
                    <th>
                        <a class="nav-link" href="<?php echo e(route('anak.edit',$anak->id)); ?>">
                            <i class="material-icons">edit</i> Edit
                          </a>
                          <a class="nav-link" href="<?php echo e(route('anak.hapus',$anak->id)); ?>">
                            <i class="material-icons">remove_circle</i> Hapus
                          </a>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>

        </form>

        </div>
      </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="<?php echo e(url('dataAnak.insert')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
        </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Data Anak', 'titlePage' => __('Data Anak')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/dataAnak.blade.php ENDPATH**/ ?>