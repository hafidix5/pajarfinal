<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                      <th>
                        Nama
                      </th>
                      <th>
                        Singkatan
                      </th>
                      <th>
                        Link Grup WA
                      </th>
                    <th>
                        Aksi
                    </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $jenisEdukasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisEdukasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($jenisEdukasi->nama); ?></td>
                            <td><?php echo e($jenisEdukasi->singkatan); ?></td>
                            <td>
                                <a href="<?php echo e($jenisEdukasi->link_wa); ?>" target="_blank"><?php echo e($jenisEdukasi->link_wa); ?></a>

                            </td>
                            <th>
                                <a class="nav-link" href="<?php echo e(route('jenisEdukasi.edit',$jenisEdukasi->id)); ?>">
                                    <i class="material-icons">edit</i> Edit
                                  </a>
                                  <a class="nav-link" href="<?php echo e(route('jenisEdukasi.hapus',$jenisEdukasi->id)); ?>">
                                    <i class="material-icons">remove_circle</i> Hapus
                                  </a>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(url('jenisEdukasi.insert')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
                </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Jenis Edukasi', 'titlePage' => __('Jenis Edukasi')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/jenisEdukasi.blade.php ENDPATH**/ ?>