<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                      <th>
                        Nama Anak
                      </th>
                      <th>
                        Nama Orang Tua
                      </th>
                      <th>
                        Puskesmas
                      </th>
                    <th>
                        Aksi
                    </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarhasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarhasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($daftarhasil->namaAnak); ?></td>
                            <td><?php echo e($daftarhasil->namaOrtu); ?></td>
                            <td><?php echo e($daftarhasil->namaPuskesmas); ?></td>
                            <th>
                                <a class="nav-link" href="<?php echo e(route('hasil_kuesioner_instingAdmin',[$daftarhasil->id,$id_jenisEdukasi])); ?>">
                                    <i class="material-icons">help_outline</i> Lihat
                                  </a>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Daftar Hasil Insting', 'titlePage' => __('Daftar Hasil Insting')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/daftarHasilInstingAdmin.blade.php ENDPATH**/ ?>