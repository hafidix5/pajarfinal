<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('jenisEdukasi.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Jenis Edukasi')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nama')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('Nama')); ?>" value="" required="true" aria-required="true"/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Singkatan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('singkatan') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('singkatan') ? ' is-invalid' : ''); ?>" name="singkatan" id="input-singkatan" type="text" placeholder="<?php echo e(__('singkatan')); ?>" value="" required="true" aria-required="true"/>
                        <?php if($errors->has('singkatan')): ?>
                          <span id="singkatan-error" class="error text-danger" for="input-singkatan"><?php echo e($errors->first('singkatan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Link Group WA')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('link_wa') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('link_wa') ? ' is-invalid' : ''); ?>" name="link_wa" id="input-link_wa" type="text" placeholder="<?php echo e(__('masukkan link grup WA')); ?>" value="" required="true" aria-required="true"/>
                        <?php if($errors->has('link_wa')): ?>
                          <span id="link_wa-error" class="error text-danger" for="input-link_wa"><?php echo e($errors->first('link_wa')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Jenis Edukasi', 'titlePage' => __('Jenis Edukasi')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/jenisEdukasiInsert.blade.php ENDPATH**/ ?>