<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('pertanyaan_ramodif.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Tambah')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Nomor')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('id') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('id') ? ' is-invalid' : ''); ?>" name="id" id="input-id" type="text" placeholder="<?php echo e(__('Nomor pertanyaan')); ?>" value="" required="true" aria-required="true"/>
                        <?php if($errors->has('id')): ?>
                          <span id="id-error" class="error text-danger" for="input-id"><?php echo e($errors->first('id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Pertanyaan')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('pertanyaan') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('pertanyaan') ? ' is-invalid' : ''); ?>" name="pertanyaan" id="input-pertanyaan" type="text" placeholder="<?php echo e(__('pertanyaan')); ?>" value="" required="true" aria-required="true"/>
                      <?php if($errors->has('pertanyaan')): ?>
                        <span id="pertanyaan-error" class="error text-danger" for="input-pertanyaan"><?php echo e($errors->first('pertanyaan')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tahap Ramodif')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tahap') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="tahap" id="tahap">
                            <option value="1.responding">Responding</option>
                          <option value="2.preventing">Preventing</option>
                          <option value="3.monitoring">Monitoring</option>
                          <option value="4.mentoring">Mentoring</option>
                          <option value="5.modeling">Modeling</option>
                        </select>
                      </div>
                    </div>
                  </div>
                <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('ramodif') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('ramodif') ? ' is-invalid' : ''); ?>" name="ramodif_id" id="input-ramodif" type="hidden" value="<?php echo e($ramodif_id); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('ramodif')): ?>
                          <span id="ramodif-error" class="error text-danger" for="input-ramodif"><?php echo e($errors->first('ramodif')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>


              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Tambah Pertanyaan Ramodif', 'titlePage' => __('Tambah Pertanyaan Ramodif')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/pertanyaan_ramodifInsert.blade.php ENDPATH**/ ?>