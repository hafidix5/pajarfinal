<footer class="footer">
  <div class="container-fluid">

    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>
      </div>
  </div>
</footer>
<?php /**PATH C:\laragon\www\hicoreapi\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>