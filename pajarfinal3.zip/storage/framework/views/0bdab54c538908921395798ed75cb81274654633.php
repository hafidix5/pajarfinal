<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('pasien.update')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Data Pasien')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <input type="hidden" name="id" value="<?php echo e($pasien->id); ?>">
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nama Lengkap')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('Nama')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" readonly required="true" aria-required="true"/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('HP')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('hp') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('hp') ? ' is-invalid' : ''); ?>" name="hp" id="input-hp" type="phone" placeholder="<?php echo e(__('Nomor HP')); ?>" value="<?php echo e($pasien->hp ?? ''); ?>" required />
                      <?php if($errors->has('hp')): ?>
                        <span id="hp-error" class="error text-danger" for="input-hp"><?php echo e($errors->first('hp')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tanggal lahir')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('tgl_lahir') ? ' is-invalid' : ''); ?>" name="tgl_lahir" id="input-tgl_lahir" type="date" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->tgl_lahir ?? ''); ?>" required />
                        <?php if($errors->has('tgl_lahir')): ?>
                          <span id="tgl_lahir-error" class="error text-danger" for="input-tgl_lahir"><?php echo e($errors->first('tgl_lahir')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Jenis kelamin')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('jk') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="jk" id="jk">
                            <?php if($pasien->jk): ?>
                            <option value="<?php echo e($pasien->jk ?? ''); ?>" selected><?php echo e($pasien->jk ?? ''); ?></option>
                            <option value="laki-laki">Laki-laki</option>
                            <option value="perempuan">Perempuan</option>
                            <?php endif; ?>
                          </select>
                        <?php if($errors->has('jk')): ?>
                          <span id="jk-error" class="error text-danger" for="input-jk"><?php echo e($errors->first('jk')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Alamat')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('alamat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" name="alamat" id="input-alamat" type="text" placeholder="<?php echo e(__('alamat tempat tinggal')); ?>" value="<?php echo e($pasien->alamat ?? ''); ?>" required />
                        <?php if($errors->has('alamat')): ?>
                          <span id="alamat-error" class="error text-danger" for="input-alamat"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pekerjaan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pekerjaan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pekerjaan" id="pekerjaan">
                        <?php if($pasien->pekerjaan): ?>
                          <option value="<?php echo e($pasien->pekerjaan ?? ''); ?>" selected><?php echo e($pasien->pekerjaan ?? ''); ?></option>
                          <option value="Ibu rumah tangga">Ibu rumah tangga</option>
                          <option value="Pensiunan">Pensiunan</option>
                          <option value="PNS">PNS</option>
                          <option value="Petani/Buruh">Petani/Buruh</option>
                          <option value="Wiraswasta">Wiraswasta</option>
                          <option value="Tidak bekerja">Tidak bekerja</option>
                        <?php endif; ?>
                        </select>
                        <?php if($errors->has('pekerjaan')): ?>
                          <span id="pekerjaan-error" class="error text-danger" for="input-pekerjaan"><?php echo e($errors->first('pekerjaan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pendidikan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pendidikan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pendidikan" id="pendidikan">
                        <?php if($pasien->pendidikan): ?>
                          <option value="<?php echo e($pasien->pendidikan ?? ''); ?>" selected><?php echo e($pasien->pendidikan ?? ''); ?></option>
                          <option value="Tidak Sekolah">Tidak Sekolah</option>
                          <option value="SD">SD</option>
                          <option value="SMP">SMP</option>
                          <option value="SMA">SMA</option>
                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                        <?php endif; ?>
                        </select>
                        <?php if($errors->has('pendidikan')): ?>
                          <span id="pendidikan-error" class="error text-danger" for="input-pendidikan"><?php echo e($errors->first('pendidikan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Status Rumah')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('status_rumah') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="status_rumah" id="status_rumah">
                        <?php if($pasien->status_rumah): ?>
                          <option value="<?php echo e($pasien->status_rumah ?? ''); ?>" selected><?php echo e($pasien->status_rumah ?? ''); ?></option>
                          <option value="pasangan">Sewa</option>
                          <option value="sendiri">Hak Milik</option>
                          <option value="anak">Rumah Orang Tua</option>
                        <?php endif; ?>
                          </select>
                        <?php if($errors->has('status_rumah')): ?>
                          <span id="status_rumah-error" class="error text-danger" for="input-status_rumah"><?php echo e($errors->first('status_rumah')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tinggal bersama')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tinggal_dengan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="tinggal_dengan" id="tinggal_dengan">
                            <?php if($pasien->tinggal_dengan): ?>
                            <option value="<?php echo e($pasien->tinggal_dengan ?? ''); ?>" selected><?php echo e($pasien->tinggal_dengan ?? ''); ?></option>
                          <option value="pasangan">Pasangan</option>
                          <option value="sendiri">Sendiri</option>
                          <option value="anak">Anak</option>
                          <option value="saudara">Saudara</option>
                          <?php endif; ?>
                          </select>
                        <?php if($errors->has('tinggal_dengan')): ?>
                          <span id="tinggal_dengan-error" class="error text-danger" for="input-tinggal_dengan"><?php echo e($errors->first('tinggal_dengan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Nama Pasangan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('nama_pasangan') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama_pasangan') ? ' is-invalid' : ''); ?>" name="nama_pasangan" id="input-nama_pasangan" type="text" placeholder="<?php echo e(__('Nama Pasangan')); ?>" value="<?php echo e($pasien->nama_pasangan ?? ''); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('nama_pasangan')): ?>
                          <span id="nama_pasangan-error" class="error text-danger" for="input-nama_pasangan"><?php echo e($errors->first('nama_pasangan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tanggal lahir Pasangan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tgl_lahir_pasangan') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('tgl_lahir_pasangan') ? ' is-invalid' : ''); ?>" name="tgl_lahir_pasangan" id="input-tgl_lahir_pasangan" type="date" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->tgl_lahir_pasangan??''); ?>" required />
                        <?php if($errors->has('tgl_lahir_pasangan_pasangan')): ?>
                          <span id="tgl_lahir_pasangan-error" class="error text-danger" for="input-tgl_lahir_pasangan"><?php echo e($errors->first('tgl_lahir_pasangan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pekerjaan Pasangan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pekerjaan_pasangan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pekerjaan_pasangan" id="pekerjaan_pasangan">
                            <?php if($pasien->pekerjaan_pasangan): ?>
                            <option value="<?php echo e($pasien->pekerjaan_pasangan ?? ''); ?>" selected><?php echo e($pasien->pekerjaan_pasangan ?? ''); ?></option>
                          <option value="Ibu rumah tangga">Ibu rumah tangga</option>
                          <option value="Pensiunan">Pensiunan</option>
                          <option value="PNS">PNS</option>
                          <option value="Petani/Buruh">Petani/Buruh</option>
                          <option value="Wiraswasta">Wiraswasta</option>
                          <option value="Tidak bekerja">Tidak bekerja</option>
                          <?php endif; ?>
                        </select>
                        <?php if($errors->has('pekerjaan_pasangan')): ?>
                          <span id="pekerjaan_pasangan-error" class="error text-danger" for="input-pekerjaan_pasangan"><?php echo e($errors->first('pekerjaan_pasangan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pendidikan pasangan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pendidikan_pasangan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pendidikan_pasangan" id="pendidikan_pasangan">
                            <?php if($pasien->pendidikan_pasangan): ?>
                            <option value="<?php echo e($pasien->pendidikan_pasangan ?? ''); ?>" selected><?php echo e($pasien->pendidikan_pasangan ?? ''); ?></option>
                          <option value="Tidak Sekolah">Tidak Sekolah</option>
                          <option value="SD">SD</option>
                          <option value="SMP">SMP</option>
                          <option value="SMA">SMA</option>
                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                          <?php endif; ?>
                        </select>
                        <?php if($errors->has('pendidikan_pasangan')): ?>
                          <span id="pendidikan_pasangan-error" class="error text-danger" for="input-pendidikan_pasangan"><?php echo e($errors->first('pendidikan_pasangan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Puskesmas')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('puskesmas_id') ? ' has-danger' : ''); ?>">
                        <select class="form-control" class="form-control" name="puskesmas_id" id="puskesmas_id">

                            <?php $__currentLoopData = $puskesmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puskesmas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
                                <?php if($pasien->puskesmas_id==$puskesmas->id): ?>
                                <option value="<?php echo e($puskesmas->id); ?>" selected><?php echo e($puskesmas->nama); ?></option>
                                <?php endif; ?>
                          <option value="<?php echo e($puskesmas->id); ?>"><?php echo e($puskesmas->nama); ?></option>
                            }
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        <?php if($errors->has('puskesmas_id')): ?>
                          <span id="puskesmas_id-error" class="error text-danger" for="input-puskesmas_id"><?php echo e($errors->first('puskesmas_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('user_id') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>" name="user_id" id="user_id" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e(old('name', auth()->user()->id)); ?>" required="true" aria-required="true" hidden/>
                        <?php if($errors->has('user_id')): ?>
                          <span id="user_id-error" class="error text-danger" for="input-user_id"><?php echo e($errors->first('user_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>



              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Data Diri', 'titlePage' => __('Data Diri')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/dataDiriupdate.blade.php ENDPATH**/ ?>