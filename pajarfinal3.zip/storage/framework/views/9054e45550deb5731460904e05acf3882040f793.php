<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                      <th>
                        Nama Anak
                      </th>
                      <th>
                        Tanggal
                      </th>
                      <th>
                        Jenis Edukasi
                      </th>
                    <th>
                        Hasil
                    </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hasilInsting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasilInsting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hasilInsting->nama); ?></td>
                            <td><?php echo e($hasilInsting->waktu); ?></td>
                            <td><?php echo e($hasilInsting->insting); ?></td>
                            <td><?php echo e($hasilInsting->skor); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Hasil Kuesioner Insting', 'titlePage' => __('Hasil Kuesioner Insting')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/hasilInsting.blade.php ENDPATH**/ ?>