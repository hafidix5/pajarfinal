<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('pertanyaan_detekos.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Tambah')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Nomor')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('id') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('id') ? ' is-invalid' : ''); ?>" name="id" id="input-id" type="text" placeholder="<?php echo e(__('Nomor pertanyaan')); ?>" value="" required="true" aria-required="true"/>
                        <?php if($errors->has('id')): ?>
                          <span id="id-error" class="error text-danger" for="input-id"><?php echo e($errors->first('id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Pertanyaan')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('pertanyaan') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('pertanyaan') ? ' is-invalid' : ''); ?>" name="pertanyaan" id="input-pertanyaan" type="text" placeholder="<?php echo e(__('pertanyaan')); ?>" value="" required="true" aria-required="true"/>
                      <?php if($errors->has('pertanyaan')): ?>
                        <span id="pertanyaan-error" class="error text-danger" for="input-pertanyaan"><?php echo e($errors->first('pertanyaan')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('insting') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('insting') ? ' is-invalid' : ''); ?>" name="detekos_id" id="input-insting" type="hidden" value="<?php echo e($detekos_id); ?>" required="true" aria-required="true"/>
                        <?php if($errors->has('insting')): ?>
                          <span id="insting-error" class="error text-danger" for="input-insting"><?php echo e($errors->first('insting')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>


              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Tambah Pertanyaan Deteks', 'titlePage' => __('Tambah Pertanyaan Deteks')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/pertanyaan_detekosInsert.blade.php ENDPATH**/ ?>