<div class="sidebar" data-color="green" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="#" class="simple-text logo-normal">
      <?php echo e(__('WEB PAJAR')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
        <?php if(Auth::check()&& Auth::user()->role  == "1"): ?>
        <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dataDiri')); ?>">
              <i class="material-icons">content_paste</i>
                <p><?php echo e(__('Data Diri')); ?></p>
            </a>
          </li>
          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dataAnak')); ?>">
              <i class="material-icons">how_to_reg</i>
                <p><?php echo e(__('Data Anak')); ?></p>
            </a>
          </li>

      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a href="#instingpSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
             <i class="material-icons">library_books</i>
             INSTING
            </a>
        <ul class="collapse list-unstyled" id="instingpSubmenu">
            <li class="nav-link">
                <a  href="<?php echo e(route('pilihEdukasi')); ?>">Lihat</a>
            </li>
            <li class="nav-link">
              <a  href="<?php echo e(route('pilihEdukasiHasilInsting')); ?>">Hasil</a>
            </li>
        </ul>
      </li>

      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a href="#detekospSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
             <i class="material-icons">assignment_turned_in</i>
             DETEKS
            </a>
        <ul class="collapse list-unstyled" id="detekospSubmenu">
            <li class="nav-link">
                <a  href="<?php echo e(route('pilihEdukasiDeteks')); ?>">Lihat</a>
            </li>
            <li class="nav-link">
              <a  href="<?php echo e(route('pilihEdukasiHasilDetekos')); ?>">Hasil</a>
            </li>
        </ul>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a href="#testimoniSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
             <i class="material-icons">assignment_turned_in</i>
             TESTIMONI DETEKS
            </a>
        <ul class="collapse list-unstyled" id="testimoniSubmenu">
            <li class="nav-link">
                <a  href="<?php echo e(route('testimoniDeteks')); ?>">Lihat</a>
            </li>
        </ul>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a href="#ramodifSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
             <i class="material-icons">grading</i>
             RAMODIF
            </a>
        <ul class="collapse list-unstyled" id="ramodifSubmenu">
            <li class="nav-link">
                <a  href="<?php echo e(route('pilihEdukasiRamodif')); ?>">Lihat</a>
            </li>
            <li class="nav-link">
              <a  href="<?php echo e(route('pilihEdukasiHasilRamodif')); ?>">Hasil</a>
            </li>
        </ul>
      </li>


        <?php endif; ?>

      <?php if(Auth::check()&& Auth::user()->role  == "2"): ?>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Beranda')); ?></p>
        </a>
      </li>
    </li>

      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
          <a class="nav-link" href="<?php echo e(route('jenisEdukasi')); ?>">
            <i class="material-icons">face</i>
            <p><?php echo e(__('Jenis Edukasi')); ?></p>
          </a>
        </li>

          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a href="#instingSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
                 <i class="material-icons">library_books</i>
                 INSTING
                </a>
            <ul class="collapse list-unstyled" id="instingSubmenu">
                <li class="nav-link">
                    <a  href="<?php echo e(route('insting')); ?>">Lihat</a>
                </li>
                <li class="nav-link">
                  <a  href="<?php echo e(route('pilihEdukasiHasilInstingAdmin')); ?>">Hasil</a>
                </li>
            </ul>
          </li>
          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a href="#deteksSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
                 <i class="material-icons">assignment_turned_in</i>
                 DETEKS
                </a>
            <ul class="collapse list-unstyled" id="deteksSubmenu">
                <li class="nav-link">
                    <a  href="<?php echo e(route('detekos')); ?>">Lihat</a>
                </li>
                <li class="nav-link">
                  <a  href="<?php echo e(route('pilihEdukasiHasilDetekosAdmin')); ?>">Hasil</a>
                </li>
            </ul>
          </li>
          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('testimoni')); ?>">
              <i class="material-icons">assignment_turned_in</i>
                <p><?php echo e(__('TESTIMONI DETEKS')); ?></p>
            </a>
          </li>
          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a href="#ramodifSubmenu" data-toggle="collapse" aria-expanded="false" class="nav-link">
                 <i class="material-icons">grading</i>
                 RAMODIF
                </a>
            <ul class="collapse list-unstyled" id="ramodifSubmenu">
                <li class="nav-link">
                    <a  href="<?php echo e(route('ramodif')); ?>">Lihat</a>
                </li>
                <li class="nav-link">
                  <a  href="<?php echo e(route('pilihEdukasiHasilRamodifAdmin')); ?>">Hasil</a>
                </li>
            </ul>
          </li>

          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('puskesmas')); ?>">
              <i class="material-icons">grading</i>
              <p><?php echo e(__('Puskesmas')); ?></p>
            </a>
          </li>


      <?php endif; ?>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="pilihGroup">
            <i class="material-icons">chat</i>
            <p><?php echo e(__('Konsultasi Keluarga')); ?></p>
          </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="https://forms.gle/LcAtNgfrBZNaPv5Z7" target="_blank">
            <i class="material-icons">feedback</i>
            <p><?php echo e(__('Tanggapan')); ?></p>
          </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Keluar')); ?>


        <i class="material-icons">settings_power</i>

        </a>
      </li>


    </ul>
  </div>
</div>
<?php /**PATH C:\laragon\www\pajarfinal\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>