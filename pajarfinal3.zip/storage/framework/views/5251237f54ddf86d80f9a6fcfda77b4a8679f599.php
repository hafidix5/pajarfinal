<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Pilih Jenis Edukasi')); ?></h4>
              </div><br>
              <?php $__currentLoopData = $jenisEdukasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisEdukasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="btn btn-outline-success btn-lg btn-block" href="<?php echo e(route('pilihAnakRamodif',$jenisEdukasi->id)); ?>"><?php echo e($jenisEdukasi->nama); ?></a>
              <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
      </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Jenis Edukasi', 'titlePage' => __('Jenis Edukasi')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/pilihjenisEdukasiRamodif.blade.php ENDPATH**/ ?>