<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Insting</h4>
        <p class="card-category">Kuesioner Informasi Penting</p>
      </div>

      <div class="card-body">
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><h4><?php echo e(session('status')); ?><h4>

            </span>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <div class="embed-responsive embed-responsive-16by9">
      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($video->video); ?>?rel=0" allowfullscreen></iframe>
      </div>
      <br><br>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="">
              <th>
                Nomor
              </th>
              <th>
                Pertanyaan
              </th>
              <th>
                Jawaban&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;
              </th>

            </thead>
            <tbody>
                <form method="post" action="<?php echo e(route('kuesioner_instingSave',[$id_anak,$video->id])); ?>" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
                    <?php $i=1; ?>
            <?php $__currentLoopData = $detail_insting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_insting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($detail_insting->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($detail_insting->id); ?> name=<?php echo e('pertanyaan'.$detail_insting->id); ?> value="1" required/> Benar</span><br>
                        <span><input type="radio" id=<?php echo e($detail_insting->id); ?> name=<?php echo e('pertanyaan'.$detail_insting->id); ?> value="0"/> Salah</span><br/>
                   </div>
                    </td>

                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
          </table>
          <div class="card-footer ml-auto mr-auto">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Isi kuesioner', 'titlePage' => __('Isi kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/kuesioner_insting.blade.php ENDPATH**/ ?>