<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Deteks</h4>
        <p class="card-category">Video Testimoni </p>
      </div>

      <div class="card-body">
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><h4><?php echo e(session('status')); ?><h4>

            </span>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <?php $__currentLoopData = $testimoniDeteks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimoniDeteks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="embed-responsive embed-responsive-16by9">
      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($testimoniDeteks->video); ?>?rel=0" allowfullscreen></iframe>
      </div>
      <h4><?php echo e($testimoniDeteks->nama); ?></h4>
      <br><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '', 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pajarfinal\resources\views/pages/testimoniDeteks.blade.php ENDPATH**/ ?>